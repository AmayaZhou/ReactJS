import React, { Component } from 'react';

const Context = React.createContext();

export class Provider extends Component {
    // global state
    state = {
        contacts: [
            {
                id: 1,
                name: 'John Doe',
                email: 'joe@gmail.com',
                phone: '123-123-1234'
            },
            {
                id: 2,
                name: 'Karen Williams',
                email: 'karen@gmail.com',
                phone: '222-123-1234'
            },
            {
                id: 3,
                name: 'Henry Johnson',
                email: 'henry@gmail.com',
                phone: '333-123-1234'
            }
        ]
    }

    render() {
        return (
            <Context.Provider value={this.state}>
                {this.props.children}
            </Context.Provider>
        )
    }
}

export const Consumer = Context.Consumer;