import React, { Component } from 'react';
import Contacts from './components/contacts';
import Header from './components/Header'; // shift+option+arrow-down: copy
// 如果再引用某个包的时候，这个包被安装到了 node_modules目录中，则可以省略 node_modules这一层目录
// 直接以包名开始引入自己的 模块 或样式表

// import { Provider } from './context';

import 'bootstrap/dist/css/bootstrap.min.css'; // in node_modules file
import './App.css';

class App extends Component {
  render() {

    return (
      // <Provider>
      <div className="App">
        {/* {showHello ? <h4>hello {name.toUpperCase()}</h4> : null}
          {math} */}
        <Header />
        <div className="container">
          <Contacts></Contacts>
          {/* <Contact name="John Doe" email="jdoe@gmail.com" phone="555-555-5555" />
            <Contact name="Karen Smith" email="karen@gmail.com" phone="333-333-3333" /> */}
        </div>

      </div>
      // </Provider>

    );
  }
}

export default App;
