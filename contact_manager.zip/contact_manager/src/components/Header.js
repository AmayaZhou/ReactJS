// rfc
import React from 'react';
// imtp
import PropTypes from 'prop-types';


const Header = (props) => {
    const { branding } = props; // 如果是class，那么要用this.props.  如果是function,直接用props.
    return (
        <div>
            {/* inline CSS, use {{}} */}
            <nav className="navbar navbar-expand-sm navbar-dark bg-info mb-3 py-0">
                <div className="container">
                    <a href="/" className="navbar-brand">
                        {branding}
                    </a>
                    <div>
                        <ul className="navbar-nav mr-auto">
                            <li className="nav-item">
                                <a href="/" className="nav-link">Home</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    );
}

Header.defaultProps = { branding: 'My Contacts' };

Header.propTypes = {
    // validate input
    branding: PropTypes.string.isRequired
};

// const headingStyle = {
//     color: 'green',
//     fontSize: '50px'
// };

export default Header;

