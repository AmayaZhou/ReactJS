import React, { Component } from 'react'
import Contact from './Contact'
// import { Consumer } from '../context'

class contacts extends Component {
    // constructor() {
    //     super();
    //     this.state = {
    // 上面的constructor可以省略

    // }

    state = {
        contacts: [
            {
                id: 1,
                name: 'John Doe',
                email: 'joe@gmail.com',
                phone: '123-123-1234'
            },
            {
                id: 2,
                name: 'Karen Williams',
                email: 'karen@gmail.com',
                phone: '222-123-1234'
            },
            {
                id: 3,
                name: 'Henry Johnson',
                email: 'henry@gmail.com',
                phone: '333-123-1234'
            }
        ]
    }

    deleteContact = (id) => {
        // console.log(id);
        // 通过filter函数过虑掉被选中的id，留下没有被选中的，再设置给新的contacts
        const { contacts } = this.state;

        const newContacts = contacts.filter(contact => contact.id !== id);

        this.setState({
            contacts: newContacts
        });
    };

    // render() {
    //     return (
    //         <Consumer>
    //             {value => {
    //                 const { contacts } = value;
    //                 return (
    //                     <React.Fragment>
    //                         {contacts.map(contact =>
    //                             <Contact {...contact} key={contact.id} deleteClickHander={this.deleteContact.bind(this, contact.id)} />)}
    //                     </React.Fragment>
    //                 )
    //             }}
    //         </Consumer>
    //     )
    // }

    render() {
        const { contacts } = this.state;
        return (
            <React.Fragment>
                {contacts.map(contact =>
                    <Contact {...contact} key={contact.id} deleteClickHander={this.deleteContact.bind(this, contact.id)} />)}
            </React.Fragment>
        )
    }
}

export default contacts;