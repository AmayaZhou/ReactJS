import React, { Component } from 'react'; // input rcc/rce to fast generate the template
// imtp
import PropTypes from 'prop-types';



class Contact extends Component {
    // static propTypes = {
    //     name: PropTypes.string.isRequired,
    //     phone: PropTypes.string.isRequired,
    //     email: PropTypes.string.isRequired,
    // };
    state = {
        showContactInfo: true
    };

    // 如果不用 arrow function, 就必须要bind(this)
    // onShowClick = e => {
    //     this.setState({ showContactInfo: !this.state.showContactInfo });
    // }

    onDeleteClick = () => {
        this.props.deleteClickHander();
    }

    render() {
        const { name, email, phone } = this.props; // deconstructering
        const { showContactInfo } = this.state;
        return (
            <div className="card card-body mb-3">
                {/* 如果是class，那么要用this.props.  如果是function,直接用props. */}
                {/* onClick={this.onShowClick.bind(this, name)} 可以用bind来传参 */}
                <h4>{name}{' '}
                    <i className="fas fa-sort-down" onClick={() => this.setState({ showContactInfo: !this.state.showContactInfo })} style={{ cursor: 'pointer' }} />
                    <i className="fas fa-times" style={{ cursor: 'pointer', float: 'right', color: 'gray' }} onClick={this.onDeleteClick} />
                </h4>
                {showContactInfo ? (<ul className="list-group">
                    <li className="list-group-item">Email: {email}</li>
                    <li className="list-group-item">Phone: {phone}</li>
                </ul>) : null}

            </div >
        )
    }
}

// Contact.propTypes = {
//     name: PropTypes.string.isRequired,
//     phone: PropTypes.string.isRequired,
//     email: PropTypes.string.isRequired,
// }

// Contact.propTypes = {
//     contact: PropTypes.object.isRequired,
//     deleteClickHander: PropTypes.func.isRequired
// };

export default Contact;
